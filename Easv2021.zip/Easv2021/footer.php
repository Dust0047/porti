<!-- Footer -->
<div id="footer">
    <div class="container">
        Dustin Chwalek 
</div>
</div>

</body>
</html>