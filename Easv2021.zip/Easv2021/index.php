<?php get_header(); ?>

<div class="main">
    <div class="container">
    <img src= "<?php echo get_template_directory_uri()?>/images/cloud.svg" height="128" width="196"/>

    <?php while(have_posts()) : the_post() ?>


    <h2><?php the_title(); ?></h2>
    <p><?php the_content(); ?></p>
    <p> HEJ THRERE </p>
    </div>
    </div>



    <?php endwhile; ?> 

    <div class="jumbotron">
    <div class="container">

    <h1> 
        stay true 
    </h1>
    <p> som text
         </p>
    <a class="btn" href=""> Contact</a>


    </div>
</div>

<?php get__footer(); ?>